<?php

class ProductVendor extends Model {
    
    public $name = 'ProductVendor';
    
}