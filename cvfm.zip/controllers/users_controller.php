<?php
class UsersController extends Controller {
    
    public $name = 'Users';
    public $components = array('Auth');
    
    /*function isAuthorized(){
        if(!parent::isAuthorized()){
            return false;
        }
        if(in_array($this->action, array('login'))){
            $this->Auth->authError = 'You are already logged in.';
            return false;
        }
        return true;
    }*/
    public function beforeFilter () {
        if (empty($this->params['prefix'])) {
            //Note an admin page
            $this->Auth->allow($this->action);
        } 
    }
    
    function admin_login() {
        
    }
    
    function logout(){
        $this->redirect($this->Auth->logout());
    }
}