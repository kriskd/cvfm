<?php

class ContentsController extends AppController {
    
    public $components = array(
                    'Auth' => array('authorize' => 'controller',
                                    'allowedActions' => array('view')));

    public function view($url){
        $content = $this->Content->findByUrl($url);
        $this->set(array('content' => $content));
        $this->layout = 'cvfm';
    }
}