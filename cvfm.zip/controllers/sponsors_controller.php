<?php

class SponsorsController extends AppController {
    
    public function isAuthorized(){
        return true;
    }
    
    public function index(){
        $sponsors = $this->Sponsor->find('all', array('order' => array('Sponsor.name')));
        $this->set(array('sponsors' => $sponsors));
        $this->layout = 'cvfm';
    }
    
    //Create Sponsor
    public function admin_add(){
        if($this->data){
            if($this->Sponsor->save($this->data)){
                $this->redirect('/admin/sponsors/add/');
            }
        }
    }
    
    //Retrieve Sponsor
    public function admin_index(){
        $sponsors = $this->Sponsor->find('all', array('order' => array('Sponsor.name')));
        $this->set(array('sponsors' => $sponsors));
    }
    
    //Update Sponsor
    
    //Delete Sponsor
}